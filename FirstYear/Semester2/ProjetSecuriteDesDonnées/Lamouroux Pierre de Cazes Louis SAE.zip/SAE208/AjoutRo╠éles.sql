GRANT patient TO 100000001;
GRANT medecin TO medecin_Pierre;
GRANT infirmier TO Infermier_Louis;
GRANT secretaire TO Secretaire_Paul;
GRANT chef_personnel TO chef_personnel_phileas;