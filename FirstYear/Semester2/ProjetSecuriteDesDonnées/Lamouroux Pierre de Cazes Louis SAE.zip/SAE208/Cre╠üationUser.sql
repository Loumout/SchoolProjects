CREATE USER 100000001 WITH PASSWORD 'motdepasse1';
CREATE USER medecin_pierre WITH PASSWORD 'motdepasse2';
CREATE USER infermier_louis WITH PASSWORD 'motdepasse3';
CREATE USER secretaire_paul WITH PASSWORD 'motdepasse4';
CREATE USER chef_personnel_phileas WITH PASSWORD 'motdepasse5';